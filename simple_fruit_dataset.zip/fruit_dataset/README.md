# Simple Fruit Dataset

A small synthetic fruit image dataset created for beginner CNN image classification practice.

## Classes
- Apple
- Banana
- Orange

## Structure
```text
fruit_dataset/
├── train/
│   ├── apple/
│   ├── banana/
│   └── orange/
└── test/
    ├── apple/
    ├── banana/
    └── orange/
```

## Image Details
- Image size: 128 × 128 pixels
- Format: PNG
- Training images: 240
- Testing images: 60
- Total images: 300

## Note
This dataset is synthetic and intended for learning only. It is not suitable for real-world fruit recognition research or production use.
